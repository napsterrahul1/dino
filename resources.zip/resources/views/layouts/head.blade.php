

<link href="{{ url('/')}}/assets/plugins/simplebar/css/simplebar.css" rel="stylesheet" />
<link href="{{ url('/')}}/assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet" />
<link href="{{ url('/')}}/assets/plugins/metismenu/css/metisMenu.min.css" rel="stylesheet" />
<!-- loader-->
<link href="{{ url('/')}}/assets/css/pace.min.css" rel="stylesheet" />
<script src="{{ url('/')}}/assets/js/pace.min.js"></script>
<!-- Bootstrap CSS -->
<link href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap5.min.css" rel="stylesheet" />


<link href="{{ url('/')}}/assets/css/bootstrap.min.css" rel="stylesheet">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300;400;600;800&display=swap" rel="stylesheet">
<link href="{{ url('/')}}/assets/css/app.css" rel="stylesheet">
<link href="{{ url('/')}}/assets/css/icons.css" rel="stylesheet">
<link href="{{ url('/')}}/assets/css/custom-style.css" rel="stylesheet">


