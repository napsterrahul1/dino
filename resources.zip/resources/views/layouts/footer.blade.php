	<!--plugins-->
<!--end page wrapper -->
		<!--start overlay-->
		<div class="overlay toggle-icon"></div>
		<!--end overlay-->
		<!--Start Back To Top Button--> <a href="javaScript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>
		<!--End Back To Top Button-->
		<footer class="page-footer">
			<p class="mb-0">Copyright © 2021. All right reserved.</p>
		</footer>

	<script src="{{ url('/')}}/assets/js/bootstrap.bundle.min.js"></script>
	<!--plugins-->
	<script src="{{ url('/')}}/assets/js/jquery.min.js"></script>
	<script src="{{ url('/')}}/assets/plugins/simplebar/js/simplebar.min.js"></script>
	<script src="{{ url('/')}}/assets/plugins/metismenu/js/metisMenu.min.js"></script>
	<script src="{{ url('/')}}/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>

	<script src="{{ url('/')}}/assets/js/dashboard-digital-marketing.js"></script>
	<!--app JS-->


	<script src="{{ url('/')}}/assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
	<script src="{{ url('/')}}/assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>
	
